<?php
/**
 * PUBLIC SCHOOL INFORMATION
 * Replace the sample values below with the school's verified information.
 * This file is safe to edit without changing the registration/payment code.
 */
$schoolProfile = [
    'name' => 'TESO SECONDARY SCHOOL',
    'short_name' => 'TESO',
    'motto' => 'Learning Today, Leading Tomorrow',
    'tagline' => 'A place to learn, grow and build a brighter future.',
    'about' => 'TESO Secondary School is committed to providing a supportive learning environment where students develop knowledge, confidence, discipline and practical skills.',
    'address' => 'Add the school town, kebele, street and nearby landmark here',
    'phone' => '+251-XX-XXX-XXXX',
    'email' => 'info@your-school-domain.com',
    'office_hours' => 'Monday – Friday, 8:00 AM – 5:00 PM',
    // Replace these sample photo URLs with your own school photographs if available.
    'photos' => [
        ['url' => 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=1200&q=85', 'title' => 'School campus', 'description' => 'A welcoming place for learning'],
        ['url' => 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=1200&q=85', 'title' => 'Classroom learning', 'description' => 'Supporting students in the classroom'],
        ['url' => 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1200&q=85', 'title' => 'Student activities', 'description' => 'Learning and participating together'],
        ['url' => 'https://images.unsplash.com/photo-1529390079861-591de354faf5?auto=format&fit=crop&w=1200&q=85', 'title' => 'School community', 'description' => 'Building a strong school community'],
    ],
];
