<?php
require_once __DIR__ . '/auth.php'; require_admin(); verify_csrf();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action=$_POST['action']??'';
    if ($action==='delete') {
        $pdo->prepare('DELETE FROM students WHERE id=?')->execute([(int)$_POST['id']]);
        flash('Student deleted.'); redirect('students.php');
    }
    $data=[
        trim($_POST['admission_no']??''),trim($_POST['full_name']??''),$_POST['gender']??'',
        $_POST['dob']?:null,trim($_POST['grade']??''),trim($_POST['section']??''),
        trim($_POST['phone']??''),trim($_POST['guardian_name']??''),trim($_POST['guardian_phone']??''),
        trim($_POST['address']??''),$_POST['status']??'Active'
    ];
    if (!$data[0] || !$data[1] || !$data[4]) { flash('Admission number, name and grade are required.','danger'); redirect('students.php');}
    if ($action==='update') {
        $data[]=(int)$_POST['id'];
        $pdo->prepare('UPDATE students SET admission_no=?,full_name=?,gender=?,date_of_birth=?,grade=?,section=?,phone=?,guardian_name=?,guardian_phone=?,address=?,status=? WHERE id=?')->execute($data);
        flash('Student updated.');
    } else {
        $pdo->prepare('INSERT INTO students(admission_no,full_name,gender,date_of_birth,grade,section,phone,guardian_name,guardian_phone,address,status) VALUES(?,?,?,?,?,?,?,?,?,?,?)')->execute($data);
        flash('Student added.');
    }
    redirect('students.php');
}
$edit=null;
if (isset($_GET['edit'])) { $st=$pdo->prepare('SELECT * FROM students WHERE id=?');$st->execute([(int)$_GET['edit']]);$edit=$st->fetch(); }
$q=trim($_GET['q']??'');
$stmt=$pdo->prepare("SELECT * FROM students WHERE admission_no LIKE ? OR full_name LIKE ? OR grade LIKE ? ORDER BY id DESC");
$like="%$q%";$stmt->execute([$like,$like,$like]);$students=$stmt->fetchAll();
$pageTitle='Student Management';require 'header.php';
?>
<div class="two-col">
<section class="panel"><div class="panel-heading"><h3><?=$edit?'Edit student':'Register student'?></h3></div>
<form method="post" class="form-grid">
<?=csrf_field()?><input type="hidden" name="action" value="<?=$edit?'update':'create'?>"><?php if($edit):?><input type="hidden" name="id" value="<?=(int)$edit['id']?>"><?php endif;?>
<label>Admission number *<input name="admission_no" required value="<?=e($edit['admission_no']??'')?>"></label>
<label>Full name *<input name="full_name" required value="<?=e($edit['full_name']??'')?>"></label>
<label>Gender<select name="gender"><option value="">Select</option><?php foreach(['Male','Female','Other'] as $v):?><option <?=$v===($edit['gender']??'')?'selected':''?>><?=$v?></option><?php endforeach;?></select></label>
<label>Date of birth<input type="date" name="dob" value="<?=e($edit['date_of_birth']??'')?>"></label>
<label>Grade / Class *<input name="grade" required placeholder="Grade 9" value="<?=e($edit['grade']??'')?>"></label>
<label>Section<input name="section" placeholder="A" value="<?=e($edit['section']??'')?>"></label>
<label>Student phone<input name="phone" value="<?=e($edit['phone']??'')?>"></label>
<label>Guardian name<input name="guardian_name" value="<?=e($edit['guardian_name']??'')?>"></label>
<label>Guardian phone<input name="guardian_phone" value="<?=e($edit['guardian_phone']??'')?>"></label>
<label class="span-2">Address<textarea name="address" rows="2"><?=e($edit['address']??'')?></textarea></label>
<label>Status<select name="status"><?php foreach(['Active','Inactive','Graduated','Transferred'] as $v):?><option <?=$v===($edit['status']??'Active')?'selected':''?>><?=$v?></option><?php endforeach;?></select></label>
<div class="form-actions span-2"><button class="btn primary">Save student</button><?php if($edit):?><a class="btn" href="students.php">Cancel</a><?php endif;?></div>
</form></section>
<section class="panel"><div class="panel-heading"><div><h3>Student directory</h3><p class="muted"><?=count($students)?> matching record(s)</p></div></div>
<form class="search" method="get"><input name="q" placeholder="Search name, admission no. or grade" value="<?=e($q)?>"><button class="btn">Search</button></form>
<div class="table-wrap"><table><thead><tr><th>Admission</th><th>Name</th><th>Grade</th><th>Action</th></tr></thead><tbody>
<?php foreach($students as $s):?><tr><td><?=e($s['admission_no'])?></td><td><?=e($s['full_name'])?></td><td><?=e($s['grade'])?> <?=e($s['section'])?></td><td class="actions"><a href="?edit=<?=(int)$s['id']?>">Edit</a><form method="post" onsubmit="return confirm('Delete this student and related marks?')"><?=csrf_field()?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=(int)$s['id']?>"><button class="link danger-text">Delete</button></form></td></tr><?php endforeach;?>
<?php if(!$students):?><tr><td colspan="4" class="empty">No matching students.</td></tr><?php endif;?>
</tbody></table></div></section></div>
<?php require 'footer.php'; ?>
