CREATE DATABASE IF NOT EXISTS teso_sms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE teso_sms;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(150) NOT NULL,
 username VARCHAR(80) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('admin','teacher') NOT NULL DEFAULT 'teacher',
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS students (
 id INT AUTO_INCREMENT PRIMARY KEY,
 admission_no VARCHAR(50) NOT NULL UNIQUE,
 full_name VARCHAR(160) NOT NULL,
 gender ENUM('Male','Female','Other') DEFAULT NULL,
 date_of_birth DATE DEFAULT NULL,
 grade VARCHAR(40) NOT NULL,
 section VARCHAR(20) DEFAULT NULL,
 phone VARCHAR(40) DEFAULT NULL,
 guardian_name VARCHAR(150) DEFAULT NULL,
 guardian_phone VARCHAR(40) DEFAULT NULL,
 address TEXT DEFAULT NULL,
 status ENUM('Active','Inactive','Graduated','Transferred') NOT NULL DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS teachers (
 id INT AUTO_INCREMENT PRIMARY KEY,
 staff_no VARCHAR(50) DEFAULT NULL UNIQUE,
 full_name VARCHAR(160) NOT NULL,
 phone VARCHAR(40) DEFAULT NULL,
 email VARCHAR(150) DEFAULT NULL,
 specialization VARCHAR(120) DEFAULT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS courses (
 id INT AUTO_INCREMENT PRIMARY KEY,
 course_code VARCHAR(30) NOT NULL UNIQUE,
 course_name VARCHAR(120) NOT NULL,
 max_mark DECIMAL(7,2) NOT NULL DEFAULT 100,
 pass_mark DECIMAL(7,2) NOT NULL DEFAULT 50,
 teacher_id INT DEFAULT NULL,
 CONSTRAINT fk_course_teacher FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS marks (
 id INT AUTO_INCREMENT PRIMARY KEY,
 student_id INT NOT NULL,
 course_id INT NOT NULL,
 mark DECIMAL(7,2) NOT NULL,
 academic_year VARCHAR(20) NOT NULL,
 term VARCHAR(30) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY unique_student_course_term (student_id,course_id,academic_year,term),
 CONSTRAINT fk_mark_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
 CONSTRAINT fk_mark_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Demo admin account: username admin, password password
-- Replace this password immediately after first login in a real deployment.
INSERT IGNORE INTO users(full_name,username,password_hash,role)
VALUES ('SMS Administrator','admin',
'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin');

ALTER TABLE students ADD COLUMN IF NOT EXISTS photo_path VARCHAR(255) DEFAULT NULL,
 ADD COLUMN IF NOT EXISTS registration_status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved';
CREATE TABLE IF NOT EXISTS student_accounts (
 id INT AUTO_INCREMENT PRIMARY KEY, student_id INT NOT NULL UNIQUE,
 username VARCHAR(80) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL,
 is_active TINYINT(1) NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS school_payment_settings (
 id TINYINT PRIMARY KEY, bank_name VARCHAR(120) NOT NULL DEFAULT '',
 account_name VARCHAR(160) NOT NULL DEFAULT '', account_number VARCHAR(80) NOT NULL DEFAULT '',
 registration_fee DECIMAL(10,2) NOT NULL DEFAULT 0, payment_instructions TEXT,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
INSERT IGNORE INTO school_payment_settings(id,bank_name,account_name,account_number,registration_fee,payment_instructions)
VALUES(1,'Please contact school','TESO SECONDARY SCHOOL','UPDATE-ACCOUNT',0,'Ask the school office for payment instructions.');
CREATE TABLE IF NOT EXISTS registration_receipts (
 id INT AUTO_INCREMENT PRIMARY KEY, student_id INT NOT NULL, receipt_path VARCHAR(255) NOT NULL,
 original_name VARCHAR(255) NOT NULL, status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
 admin_note VARCHAR(500), uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, reviewed_at DATETIME,
 FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;
