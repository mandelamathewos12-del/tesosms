<?php
// Public school homepage. This page intentionally does not require login or a database connection.
require_once __DIR__ . '/school_profile.php';
function h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
$base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
if ($base === '/') $base = '';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Official public website of <?=h($schoolProfile['name'])?>. School information, photo gallery and online student registration.">
<title><?=h($schoolProfile['name'])?> | Official School Website</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="school-home">
<header class="site-nav"><div class="site-nav-inner">
  <a class="school-brand" href="index.php"><span class="school-crest">TESO</span><span><strong><?=h($schoolProfile['name'])?></strong><small>OFFICIAL SCHOOL WEBSITE</small></span></a>
  <nav class="main-nav"><a href="#home">Home</a><a href="#about">About</a><a href="#gallery">School Gallery</a><a href="#contact">Contact</a></nav>
  <div class="nav-actions"><a class="nav-login" href="login.php">Login</a><a class="btn primary" href="register.php">Student Registration</a></div>
</div></header>
<main>
<section class="school-hero" id="home"><div class="hero-shade"></div><div class="school-hero-content">
  <span class="hero-kicker">WELCOME TO OUR SCHOOL</span><h1><?=h($schoolProfile['name'])?></h1><p><?=h($schoolProfile['tagline'])?></p>
  <div class="hero-actions"><a class="btn hero-register" href="register.php">Register as a Student <span>→</span></a><a class="btn hero-login" href="login.php">Student / Staff Login</a></div>
  <small class="hero-note">Online registration is open. Submit your details and payment receipt for school review.</small>
</div></section>
<section class="quick-strip"><div><span class="quick-icon">✦</span><span><b>Quality Education</b><small>Learning for a better future</small></span></div><div><span class="quick-icon">◎</span><span><b>Student Development</b><small>Knowledge, skills and confidence</small></span></div><div><span class="quick-icon">⌂</span><span><b>School Community</b><small>Growing and achieving together</small></span></div></section>
<section class="school-section about-section" id="about"><div class="section-photo"><img src="<?=h($schoolProfile['photos'][0]['url'])?>" alt="School campus photograph" loading="lazy"></div><div class="section-copy"><span class="section-kicker">ABOUT OUR SCHOOL</span><h2>Welcome to <?=h($schoolProfile['name'])?></h2><p><?=h($schoolProfile['about'])?></p><p>We encourage students and families to contact the school office for admission information, academic support and other school services.</p><a class="text-link" href="register.php">Start student registration <span>→</span></a></div></section>
<section class="gallery-section" id="gallery"><div class="section-heading"><span class="section-kicker">LIFE AT TESO</span><h2>Our School Gallery</h2><p>Explore learning spaces, school life and student activities.</p></div><div class="school-gallery">
<?php foreach ($schoolProfile['photos'] as $i => $photo): ?><article class="gallery-card"><img src="<?=h($photo['url'])?>" alt="<?=h($photo['title'])?>" loading="lazy"><div><h3><?=h($photo['title'])?></h3><p><?=h($photo['description'])?></p></div></article><?php endforeach; ?>
</div><p class="photo-note">These are sample gallery photographs. Replace them with real TESO Secondary School photographs in <code>school_profile.php</code>.</p></section>
<section class="admission-banner"><div><span class="section-kicker">ADMISSIONS</span><h2>Join the TESO school community</h2><p>Create your student account, complete the registration form and upload your payment receipt.</p></div><a class="btn primary" href="register.php">Register Online <span>→</span></a></section>
<section class="contact-section" id="contact"><div class="section-heading"><span class="section-kicker">GET IN TOUCH</span><h2>Contact the School</h2><p>Visit or contact the school office for assistance.</p></div><div class="contact-grid">
<div class="contact-card"><span>⌖</span><small>SCHOOL ADDRESS</small><strong><?=h($schoolProfile['address'])?></strong></div>
<div class="contact-card"><span>☎</span><small>PHONE NUMBER</small><strong><a href="tel:<?=h(preg_replace('/[^0-9+]/', '', $schoolProfile['phone']))?>"><?=h($schoolProfile['phone'])?></a></strong></div>
<div class="contact-card"><span>✉</span><small>EMAIL ADDRESS</small><strong><a href="mailto:<?=h($schoolProfile['email'])?>"><?=h($schoolProfile['email'])?></a></strong></div>
<div class="contact-card"><span>◷</span><small>OFFICE HOURS</small><strong><?=h($schoolProfile['office_hours'])?></strong></div>
</div><p class="contact-edit-note">School contact information is editable in <code>school_profile.php</code>. Replace all sample details before publishing.</p></section>
</main>
<footer class="school-footer"><div><b><?=h($schoolProfile['name'])?></b><p><?=h($schoolProfile['motto'])?></p></div><div class="footer-links"><a href="index.php">Home</a><a href="register.php">Registration</a><a href="login.php">Login</a></div><small>© <?=date('Y')?> <?=h($schoolProfile['name'])?>. All rights reserved.</small></footer>
</body></html>
