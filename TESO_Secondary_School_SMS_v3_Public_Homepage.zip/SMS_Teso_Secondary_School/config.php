<?php
declare(strict_types=1);
session_start();

define('APP_NAME', 'TESO SECONDARY SCHOOL SMS');
define('BASE_URL', '/SMS_Teso_Secondary_School'); // Change if your folder name differs.

$dbHost = '127.0.0.1';
$dbName = 'teso_sms';
$dbUser = 'root';
$dbPass = ''; // Default XAMPP MySQL password is often blank.

try {
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database connection failed. Start Apache/MySQL in XAMPP and import database.sql. Details: ' .
        htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
}
