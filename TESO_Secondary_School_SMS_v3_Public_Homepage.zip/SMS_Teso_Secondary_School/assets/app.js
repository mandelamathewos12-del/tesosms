document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('input[type="date"]').forEach(el => el.max = new Date().toISOString().slice(0,10));
});
