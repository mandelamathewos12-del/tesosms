<?php
require_once __DIR__.'/auth.php';require_once __DIR__.'/upload_helpers.php';
$bank=$pdo->query('SELECT * FROM school_payment_settings WHERE id=1')->fetch();$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$photo=$receipt=null;
 try{
 $name=trim($_POST['full_name']??'');$username=trim($_POST['username']??'');$pw=$_POST['password']??'';$grade=trim($_POST['grade']??'');
 if(!$name||!$username||!$grade||strlen($pw)<8)throw new RuntimeException('Complete required fields. Password must be at least 8 characters.');
 $photo=store_upload('photo','profiles',['image/jpeg','image/png','image/webp'],3*1024*1024);
 if(!$photo)throw new RuntimeException('Upload your profile photo.');
 $receipt=store_upload('receipt','receipts',['image/jpeg','image/png','image/webp','application/pdf'],5*1024*1024);
 if(!$receipt)throw new RuntimeException('Upload your payment receipt.');
 $pdo->beginTransaction();$adm='PENDING-'.date('ymd').'-'.strtoupper(bin2hex(random_bytes(3)));
 $pdo->prepare("INSERT INTO students(admission_no,full_name,gender,date_of_birth,grade,section,phone,guardian_name,guardian_phone,address,status,photo_path,registration_status) VALUES(?,?,?,?,?,?,?,?,?,?,'Inactive',?,'pending')")
 ->execute([$adm,$name,$_POST['gender']??null,$_POST['dob']?:null,$grade,trim($_POST['section']??''),trim($_POST['phone']??''),trim($_POST['guardian_name']??''),trim($_POST['guardian_phone']??''),trim($_POST['address']??''),$photo]);
 $sid=(int)$pdo->lastInsertId();$pdo->prepare('INSERT INTO student_accounts(student_id,username,password_hash) VALUES(?,?,?)')->execute([$sid,$username,password_hash($pw,PASSWORD_DEFAULT)]);
 $pdo->prepare('INSERT INTO registration_receipts(student_id,receipt_path,original_name) VALUES(?,?,?)')->execute([$sid,$receipt,basename($_FILES['receipt']['name'])]);
 $pdo->commit();flash('Registration submitted. Wait for school approval.');redirect('login.php');
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();remove_local_upload($photo);remove_local_upload($receipt);$error=$e instanceof PDOException?'Username may already be used. Please try another.':$e->getMessage();}
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Student Registration | TESO SMS</title><link rel="stylesheet" href="assets/style.css"></head><body class="public-page"><main class="public-wrap">
<div class="public-header"><div class="brand-mark">SMS</div><div><h1>TESO SECONDARY SCHOOL</h1><p>Online student registration</p></div><a class="btn" href="index.php">School Home</a><a class="btn" href="login.php">Login</a></div>
<?php if($error):?><div class="alert danger"><?=e($error)?></div><?php endif;?>
<div class="public-grid"><section class="panel"><h2>Student registration form</h2><p class="muted">Create your account and upload the required documents.</p>
<form method="post" enctype="multipart/form-data" class="form-grid"><?=csrf_field()?>
<label class="span-2">Full name *<input name="full_name" required></label><label>Gender<select name="gender"><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select></label><label>Date of birth<input type="date" name="dob"></label>
<label>Grade / Class *<input name="grade" required></label><label>Section<input name="section"></label><label>Student phone<input name="phone"></label><label>Guardian name<input name="guardian_name"></label><label>Guardian phone<input name="guardian_phone"></label><label>Username *<input name="username" required></label><label>Password *<input type="password" name="password" minlength="8" required></label>
<label class="span-2">Address<textarea name="address"></textarea></label><label class="span-2">Profile photo (JPG/PNG/WEBP, max 3 MB) *<input type="file" name="photo" accept="image/jpeg,image/png,image/webp" required></label><label class="span-2">Payment receipt (image/PDF, max 5 MB) *<input type="file" name="receipt" accept="image/jpeg,image/png,image/webp,application/pdf" required></label>
<div class="span-2"><button class="btn primary">Submit registration</button></div></form></section>
<aside class="panel payment-panel"><h2>School registration payment</h2><p class="muted">Pay to this official account, then upload your receipt.</p>
<div class="payment-detail"><small>Bank name</small><strong><?=e($bank['bank_name']??'Not configured')?></strong></div><div class="payment-detail"><small>Account name</small><strong><?=e($bank['account_name']??'Not configured')?></strong></div><div class="payment-detail"><small>Account number</small><strong class="account-number"><?=e($bank['account_number']??'Not configured')?></strong></div><div class="payment-detail"><small>Registration fee</small><strong><?=number_format((float)($bank['registration_fee']??0),2)?> ETB</strong></div><div class="payment-instructions"><?=nl2br(e($bank['payment_instructions']??''))?></div><div class="alert">Registration is pending until the school verifies your receipt.</div></aside></div></main></body></html>
