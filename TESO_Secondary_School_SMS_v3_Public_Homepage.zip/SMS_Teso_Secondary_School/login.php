<?php
require_once __DIR__.'/auth.php';if(!empty($_SESSION['user']))redirect('dashboard.php');$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$username=trim($_POST['username']??'');$password=$_POST['password']??'';
 $q=$pdo->prepare('SELECT id,full_name,username,password_hash,role FROM users WHERE username=? AND is_active=1');$q->execute([$username]);$u=$q->fetch();
 if($u&&password_verify($password,$u['password_hash'])){session_regenerate_id(true);unset($u['password_hash']);$_SESSION['user']=$u;redirect('dashboard.php');}
 $q=$pdo->prepare('SELECT sa.id,sa.username,sa.password_hash,sa.is_active,s.id student_id,s.full_name,s.registration_status FROM student_accounts sa JOIN students s ON s.id=sa.student_id WHERE sa.username=?');$q->execute([$username]);$st=$q->fetch();
 if($st&&password_verify($password,$st['password_hash'])){
  if(!$st['is_active']||$st['registration_status']!=='approved')$error='Your student registration is awaiting approval. Please contact the school office.';
  else{session_regenerate_id(true);$_SESSION['user']=['id'=>$st['id'],'full_name'=>$st['full_name'],'username'=>$st['username'],'role'=>'student','student_id'=>$st['student_id']];redirect('student_portal.php');}
 }elseif(!$error)$error='Incorrect username or password.';
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SMS Login</title><link rel="stylesheet" href="assets/style.css"></head><body class="login-page"><form class="login-card" method="post"><div class="brand-mark">SMS</div><h1>TESO SECONDARY SCHOOL</h1><p class="muted">Student Management System</p><?php if($error):?><div class="alert danger"><?=e($error)?></div><?php endif;?><?=csrf_field()?><label>Username<input name="username" required></label><label>Password<input type="password" name="password" required></label><button class="btn primary full">Sign in</button><small class="muted">Administrator: admin / password</small><a class="register-link" href="register.php">New student? Register online</a><a class="register-link" href="index.php">← Back to school website</a></form></body></html>
