<?php
require_once __DIR__.'/auth.php';require_login();
if(($_SESSION['user']['role']??'')==='student')$sid=(int)$_SESSION['user']['student_id'];else{$sid=(int)($_GET['student']??0);if(!$sid)redirect('idcards.php');}
$q=$pdo->prepare("SELECT * FROM students WHERE id=? AND registration_status='approved'");$q->execute([$sid]);$s=$q->fetch();if(!$s)exit('Approved student record not found.');
if(($_SESSION['user']['role']??'')==='student'&&(int)$s['id']!==(int)$_SESSION['user']['student_id'])exit('Access denied.');
$qr=['school'=>'TESO SECONDARY SCHOOL','student_id'=>(int)$s['id'],'admission_number'=>$s['admission_no'],'full_name'=>$s['full_name'],'grade'=>$s['grade'],'section'=>$s['section']];
$pageTitle='Student ID Card';require 'header.php';?>
<section class="panel no-print"><h3>Official student identity card</h3><p class="muted">Download as PNG or print / save as PDF. QR includes school, student ID, admission number, name and class.</p></section>
<div class="id-download-wrap"><article class="id-card id-card-large" id="downloadCard"><div class="id-top"><div class="id-logo">TESO</div><div><b>TESO SECONDARY SCHOOL</b><small>OFFICIAL STUDENT IDENTITY CARD</small></div></div><div class="id-content"><div class="id-photo"><?php if($s['photo_path']):?><img src="<?=e($s['photo_path'])?>" alt="Student profile"><?php else:?><?=e(strtoupper(substr($s['full_name'],0,1)))?><?php endif;?></div><div class="id-info"><strong><?=e($s['full_name'])?></strong><span>ID: <?=e($s['admission_no'])?></span><span>Student ID: <?=e($s['id'])?></span><span>Grade: <?=e($s['grade'])?> <?=e($s['section'])?></span><span>Gender: <?=e($s['gender'])?></span></div><div class="qr id-qr" id="studentQr"></div></div><div class="id-bottom">TESO SECONDARY SCHOOL · OFFICIAL STUDENT ID</div></article><div class="no-print card-actions"><button class="btn primary" onclick="downloadCard()">Download ID card (PNG)</button><button class="btn" onclick="window.print()">Print / Save as PDF</button></div></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
const qrData=<?=json_encode(json_encode($qr,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))?>;
if(window.QRCode)new QRCode(document.getElementById('studentQr'),{text:qrData,width:92,height:92,colorDark:'#14213d',colorLight:'#ffffff'});
async function downloadCard(){if(!window.html2canvas){alert('Download library unavailable. Use Print / Save as PDF.');return;}const c=await html2canvas(document.getElementById('downloadCard'),{scale:3,useCORS:true,backgroundColor:'#fff'});const a=document.createElement('a');a.download='TESO-ID-<?=e(preg_replace('/[^A-Za-z0-9_-]/','_', $s['admission_no']))?>.png';a.href=c.toDataURL('image/png');a.click();}
</script><?php require 'footer.php';?>
