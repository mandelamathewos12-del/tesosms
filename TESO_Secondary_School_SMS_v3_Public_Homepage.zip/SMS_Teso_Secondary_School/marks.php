<?php
require_once __DIR__.'/auth.php';require_login();
if (($_SESSION['user']['role'] ?? '') === 'student') redirect('student_portal.php');verify_csrf();
if($_SERVER['REQUEST_METHOD']==='POST'){
 require_admin();
 $sid=(int)($_POST['student_id']??0);$cid=(int)($_POST['course_id']??0);$mark=(float)($_POST['mark']??-1);$year=trim($_POST['academic_year']??school_year());$term=trim($_POST['term']??'Term 1');
 $c=$pdo->prepare('SELECT max_mark FROM courses WHERE id=?');$c->execute([$cid]);$course=$c->fetch();
 if(!$sid||!$course||$mark<0||$mark>(float)$course['max_mark']){flash('Check student, course and mark range.','danger');redirect('marks.php');}
 $pdo->prepare('INSERT INTO marks(student_id,course_id,mark,academic_year,term) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE mark=VALUES(mark)')->execute([$sid,$cid,$mark,$year,$term]);
 flash('Mark saved.');redirect('marks.php');
}
$students=$pdo->query("SELECT id,admission_no,full_name FROM students WHERE status='Active' ORDER BY full_name")->fetchAll();
$courses=$pdo->query('SELECT id,course_code,course_name,max_mark FROM courses ORDER BY course_name')->fetchAll();
$rows=$pdo->query('SELECT m.*,s.full_name,s.admission_no,c.course_code,c.course_name,c.max_mark FROM marks m JOIN students s ON s.id=m.student_id JOIN courses c ON c.id=m.course_id ORDER BY m.id DESC LIMIT 150')->fetchAll();
$pageTitle='Marks & Results';require 'header.php';?>
<div class="two-col"><section class="panel"><h3>Enter / update mark</h3><?php if(is_admin()):?><form method="post" class="form-grid"><?=csrf_field()?>
<label class="span-2">Student<select name="student_id" required><option value="">Choose student</option><?php foreach($students as $s):?><option value="<?=$s['id']?>"><?=e($s['admission_no'].' — '.$s['full_name'])?></option><?php endforeach;?></select></label>
<label class="span-2">Course<select name="course_id" required><option value="">Choose course</option><?php foreach($courses as $c):?><option value="<?=$c['id']?>"><?=e($c['course_code'].' — '.$c['course_name'].' (max '.$c['max_mark'].')')?></option><?php endforeach;?></select></label>
<label>Mark obtained<input type="number" name="mark" min="0" step="0.01" required></label><label>Academic year<input name="academic_year" value="<?=e(school_year())?>" required></label><label>Term<select name="term"><option>Term 1</option><option>Term 2</option><option>Term 3</option></select></label><div class="form-actions span-2"><button class="btn primary">Save mark</button></div></form><?php else:?><p class="muted">You have view-only access to marks. Contact an administrator to enter or change marks.</p><?php endif;?></section>
<section class="panel"><h3>Recently entered marks</h3><div class="table-wrap"><table><thead><tr><th>Student</th><th>Course</th><th>Mark</th><th>Term</th><th>Year</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=e($r['full_name'])?></td><td><?=e($r['course_code'])?></td><td><?=e($r['mark'])?> / <?=e($r['max_mark'])?></td><td><?=e($r['term'])?></td><td><?=e($r['academic_year'])?></td></tr><?php endforeach;?></tbody></table></div></section></div><?php require 'footer.php';?>
