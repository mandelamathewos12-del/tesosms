TESO SCHOOL WEBSITE PHOTO GUIDE

The public homepage gallery and hero banner use sample image URLs configured in school_profile.php.
Before publishing, replace those sample images with real photographs of TESO Secondary School.

Recommended method:
1. Create a folder named assets/school.
2. Copy school photographs into that folder, for example campus.jpg, classroom.jpg, activities.jpg and students.jpg.
3. In school_profile.php, replace each sample URL with a local path such as assets/school/campus.jpg.
4. Replace the school address, phone number, email address, motto and description with verified school information.
5. Do not publish placeholder contact details.

The homepage (index.php) is public and does not require a login or database connection.
The protected staff dashboard is dashboard.php.
Student registration remains register.php and shows the payment details configured by the administrator.
