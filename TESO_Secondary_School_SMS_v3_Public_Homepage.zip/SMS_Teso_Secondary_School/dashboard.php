<?php
require_once __DIR__ . '/auth.php';
require_login();
if (($_SESSION['user']['role'] ?? '') === 'student') redirect('student_portal.php');
$pageTitle = 'Dashboard';
$stats = [];
foreach ([
    'Students' => 'SELECT COUNT(*) FROM students',
    'Teachers' => 'SELECT COUNT(*) FROM teachers',
    'Courses' => 'SELECT COUNT(*) FROM courses',
    'Marks entered' => 'SELECT COUNT(*) FROM marks'
] as $label => $sql) $stats[$label] = (int)$pdo->query($sql)->fetchColumn();
$recent = $pdo->query("SELECT s.admission_no, s.full_name, s.grade, s.status FROM students s ORDER BY s.id DESC LIMIT 6")->fetchAll();
require 'header.php';
?>
<section class="welcome"><div><span class="eyebrow light">SCHOOL OVERVIEW</span><h1>Welcome to SMS</h1><p>Manage student records, courses, teachers, marks and academic reports in one place.</p></div><div class="welcome-icon">✦</div></section>
<div class="stat-grid"><?php foreach ($stats as $label=>$value): ?><div class="stat-card"><span><?=e($label)?></span><strong><?=number_format($value)?></strong><small>Current records</small></div><?php endforeach; ?></div>
<section class="panel"><div class="panel-heading"><div><h3>Recently added students</h3><p class="muted">Latest student registrations</p></div><a class="btn primary" href="students.php">Manage students</a></div>
<div class="table-wrap"><table><thead><tr><th>Admission No.</th><th>Student name</th><th>Grade</th><th>Status</th></tr></thead><tbody>
<?php foreach ($recent as $s): ?><tr><td><?=e($s['admission_no'])?></td><td><?=e($s['full_name'])?></td><td><?=e($s['grade'])?></td><td><span class="status"><?=e($s['status'])?></span></td></tr><?php endforeach; ?>
<?php if (!$recent): ?><tr><td colspan="4" class="empty">No students yet. Add your first student.</td></tr><?php endif; ?>
</tbody></table></div></section>
<?php require 'footer.php'; ?>
