<?php
require_login();
$pageTitle = $pageTitle ?? 'Dashboard';
$flashMessage = get_flash();
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?=e($pageTitle)?> | SMS</title><link rel="stylesheet" href="assets/style.css">
<script defer src="assets/app.js"></script>
</head><body>
<aside class="sidebar">
  <a class="brand" href="index.php"><span class="brand-mark small">SMS</span><span>TESO SECONDARY<br><small>STUDENT MANAGEMENT</small></span></a>
  <nav>
    <?php if (($_SESSION['user']['role'] ?? '') === 'student'): ?>
      <a href="student_portal.php">▦ My Student Portal</a><a href="student_id.php">▣ My ID Card</a>
    <?php else: ?>
      <a href="index.php">⌂ Public website</a><a href="dashboard.php">▦ Dashboard</a><a href="students.php">♙ Students</a><a href="teachers.php">♧ Teachers</a><a href="courses.php">▤ Courses</a><a href="marks.php">✎ Marks & Results</a><a href="reports.php">▥ Ranking & Report Cards</a><a href="idcards.php">▣ Student ID Cards</a>
      <?php if (is_admin()): ?><a href="registrations.php">☷ Registration approvals</a><a href="payment_settings.php">৳ Bank settings</a><a href="users.php">⚙ User Accounts</a><?php endif; ?>
    <?php endif; ?>
  </nav>
  <div class="sidebar-bottom"><small>Signed in as</small><strong><?=e($_SESSION['user']['full_name'])?></strong><a href="logout.php">↪ Sign out</a></div>
</aside>
<main class="main">
<header class="topbar"><div><span class="eyebrow">TESO SECONDARY SCHOOL</span><h2><?=e($pageTitle)?></h2></div><div class="user-chip"><?=e($_SESSION['user']['role'])?></div></header>
<?php if ($flashMessage): ?><div class="alert <?=e($flashMessage['type'])?>"><?=e($flashMessage['message'])?></div><?php endif; ?>
