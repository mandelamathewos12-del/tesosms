# TESO Secondary School — SMS

A PHP + MySQL school management starter application for XAMPP.

## Included modules
- Admin login and teacher read-only login
- Student registration, search, edit and delete
- Teacher and course management
- Marks entry and updating by student/course/academic year/term
- Ranking by total marks and average
- Student report cards with print / Save as PDF
- Student ID cards with QR codes and print support
- Responsive dashboard and basic user account creation

## Requirements
- Windows 10/11
- XAMPP with Apache, PHP 8.0+ and MySQL/MariaDB
- A modern browser
- Internet connection for Google Fonts and the QR-code JavaScript CDN (the rest of the app runs locally)

## Installation
1. Install and open XAMPP.
2. Start **Apache** and **MySQL**.
3. Copy the `SMS_Teso_Secondary_School` folder into `C:\xampp\htdocs\`.
4. Open `http://localhost/phpmyadmin`.
5. Choose **Import**, select this project's `database.sql`, and import it.
6. Check `config.php`. Default XAMPP settings are host `127.0.0.1`, user `root`, blank password, database `teso_sms`.
7. If the folder name is unchanged, open `http://localhost/SMS_Teso_Secondary_School/login.php`.
8. Sign in using:
   - Username: `admin`
   - Password: `password`

## Important first steps
- Change the default administrator password before real use. This starter includes account creation, but not password self-service; update the admin password hash through a one-time PHP password_hash script or phpMyAdmin.
- Create teacher records, courses, student records, then enter marks.
- Use the same academic year and term when entering marks and generating rankings/report cards.
- Report cards: Reports & Report Cards → select year/term → View card → Print / Save as PDF.
- ID cards: Student ID Cards → select a student → Print selected card.
- QR codes contain school name, admission number, student name, grade and section. They do not expose guardian contacts or home address.

## Roles
- Administrator: can manage students, teachers, courses, marks and accounts.
- Teacher: can sign in and view dashboard, marks and reports. For this initial version, teacher accounts are read-only.

## Production / privacy checklist
This is a functional starter project, not a security-audited production deployment. Before putting real student information online:
- Change all default credentials and use strong unique passwords.
- Use HTTPS and a supported PHP version.
- Restrict access to the school network or add appropriate hosting/firewall controls.
- Configure automated encrypted database backups and test restoring them.
- Review data protection, parent consent, retention and access policies.
- Add audit logs, password reset, account disable/edit, attendance, fees, class promotion and import/export if needed.
- Do not publish phpMyAdmin or expose the XAMPP development server to the public internet.

## Troubleshooting
- Database connection error: confirm MySQL is running and credentials in `config.php` match your XAMPP setup.
- 404: verify the folder is inside `htdocs` and use the exact folder name in the URL.
- QR code missing: check internet connection because the QR library is loaded from a CDN.
- Marks not accepted: mark must be between 0 and the course's maximum mark.

## New self-registration and payment workflow
1. Log in as administrator and open **Bank settings**.
2. Set bank name, account holder, account number, registration fee and payment instructions.
3. Give students the public URL: `http://localhost/SMS_Teso_Secondary_School/register.php`.
4. Students create their login, enter their information, upload a profile photo (JPG/PNG/WEBP up to 3 MB), and upload a payment receipt (image/PDF up to 5 MB).
5. Administrator opens **Registration approvals**, reviews the student and receipt against the bank statement, and approves or rejects.
6. On approval, administrator assigns the official admission number. Student can then log in and use **My Student Portal** and **My ID Card**.
7. ID cards contain school name, profile photo, admission number, internal student ID, grade and a QR code. Students can download PNG or print/save as PDF.

If you already imported the earlier database, import the updated `database.sql` in phpMyAdmin. The SQL adds the new student profile and registration fields plus supporting tables. Check your MariaDB version if it does not support `ADD COLUMN IF NOT EXISTS`.

Uploaded files are stored in `uploads/profiles/` and `uploads/receipts/`. Receipt upload is not automatic bank verification. School staff must confirm payment before approval. QR codes contain only basic student identity fields, not passwords or guardian details.

## Student self-registration and bank payment setup
1. Log in as administrator and open **Bank settings**.
2. Set bank name, account holder, account number, registration fee and payment instructions.
3. Give students this URL: `http://localhost/SMS_Teso_Secondary_School/register.php`.
4. Students create a username/password, enter their information, upload a profile photo (JPG/PNG/WEBP up to 3 MB), and upload a payment receipt (image/PDF up to 5 MB).
5. Administrator opens **Registration approvals**, reviews the student and receipt against the bank statement, and approves or rejects.
6. On approval, administrator assigns the official admission number. The student can then log in to **My Student Portal** and **My ID Card**.
7. Students can update their profile photo and download their ID card as PNG or print/save as PDF.

If you already imported the older database, import the updated `database.sql` in phpMyAdmin. The updated SQL adds student profile and registration fields and the supporting account/payment tables. If your MySQL/MariaDB version does not support `ADD COLUMN IF NOT EXISTS`, add `students.photo_path VARCHAR(255) NULL` and `students.registration_status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved'` manually before importing the remaining statements.

Uploaded files are stored under `uploads/profiles/` and `uploads/receipts/`. Receipt upload is not automatic bank verification: school staff must confirm payment before approval. QR codes contain basic student identity data only, not passwords, guardian details or payment information.


## Public school homepage (Version 3)
- The website now opens at `index.php` as a public school information page. Visitors do not need an account to view it.
- The protected staff dashboard has moved to `dashboard.php`. Staff login redirects there automatically.
- The public homepage includes About, photo gallery, contact information, online registration and login links.
- Edit `school_profile.php` to replace the sample address, phone, email, school description and photo URLs. See `SCHOOL_PHOTOS_README.txt` for adding real school photos. Do not publish the sample contact details.
- Students click **Student Registration** to open `register.php`. That page displays the bank name, account holder, account number and fee saved by the administrator in Bank Settings. Students upload their profile photo and payment receipt during registration.
- Students and staff use **Login** to access their respective portals. The dashboard is not publicly accessible.

### Updated website navigation
- Public homepage: `http://localhost/SMS_Teso_Secondary_School/`
- Student registration: `http://localhost/SMS_Teso_Secondary_School/register.php`
- Login: `http://localhost/SMS_Teso_Secondary_School/login.php`
- Staff dashboard after login: `http://localhost/SMS_Teso_Secondary_School/dashboard.php`
