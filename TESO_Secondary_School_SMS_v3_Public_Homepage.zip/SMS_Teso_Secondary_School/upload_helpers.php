<?php
function store_upload(string $field,string $folder,array $allowed,int $max):?string {
 if(empty($_FILES[$field])||$_FILES[$field]['error']===UPLOAD_ERR_NO_FILE)return null;
 $f=$_FILES[$field]; if($f['error']!==UPLOAD_ERR_OK)throw new RuntimeException('Upload failed.');
 if($f['size']>$max)throw new RuntimeException('File is too large.');
 $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
 if(!in_array($mime,$allowed,true))throw new RuntimeException('Unsupported file type.');
 $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','application/pdf'=>'pdf'][$mime]??null;
 if(!$ext)throw new RuntimeException('Unsupported file type.');
 $dir=__DIR__.'/uploads/'.$folder;if(!is_dir($dir))mkdir($dir,0750,true);
 $name=bin2hex(random_bytes(16)).'.'.$ext;
 if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$name))throw new RuntimeException('Could not save upload.');
 return 'uploads/'.$folder.'/'.$name;
}
function remove_local_upload(?string $path):void {
 if(!$path)return;$f=realpath(__DIR__.'/'.$path);$root=realpath(__DIR__.'/uploads');
 if($f&&$root&&str_starts_with($f,$root.DIRECTORY_SEPARATOR)&&is_file($f))@unlink($f);
}
